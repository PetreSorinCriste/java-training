import java.util.ArrayList;
import java.util.List;

class ProxyInternet implements ReteaLocala {
    private ReteaLocala reteaLocala = new ReteaWan();

    private static List<String> siteuriInterzise;

    static {
        siteuriInterzise = new ArrayList<String>();
        siteuriInterzise.add("youtube.com");
        siteuriInterzise.add("facebook.com");
        siteuriInterzise.add("yahoo.com");
        siteuriInterzise.add("instagram.com");
    }

    @Override
    public void connectTo(String serverhost) throws Exception {
        if (siteuriInterzise.contains(serverhost.toLowerCase())) {
            throw new Exception("Acces Interzis");
        }

        reteaLocala.connectTo(serverhost);
    }
}
