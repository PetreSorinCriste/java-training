public class Client {
    public static void main(String [] args) {
        ReteaLocala reteaLocala = new ProxyInternet();

        try {
            reteaLocala.connectTo("scoalainformala.ro");
            reteaLocala.connectTo("facebook.com");
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
}
