interface ReteaLocala {
public void connectTo(String serverhost) throws Exception;
        }

class ReteaWan implements ReteaLocala {
    @Override
    public void connectTo(String serverhost) {
        System.out.println("Conectare la " + serverhost);
    }

}