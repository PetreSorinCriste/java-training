public class Client {
    public static void main(String[] args) {
        ProcesareComandaTemplate comandaOnline = new ComandaOnline();
        comandaOnline.procesareComanda(true);

        System.out.println(">>> Am schimbat 'template-ul' într-o comandă de magazin");

        ProcesareComandaTemplate storeOrder = new ComandaMagazin();
        storeOrder.procesareComanda(true);
    }
}
