abstract class ProcesareComandaTemplate{
    public boolean esteCadou;

    public abstract void deSelectat();
    public abstract void dePlatit();

    public final void ambalajCadou() {
        System.out.println("Ambalaj cadou realizat cu succes");
    }

    public abstract void deLivrat();

    // Metoda 'Template'

    public final void procesareComanda(boolean esteCadou) {
        deSelectat();
        dePlatit();

        if (esteCadou) {
            ambalajCadou();
        }

        deLivrat();
    }
}

class ComandaOnline extends ProcesareComandaTemplate {
    @Override
    public void deSelectat()  {
        System.out.println("Articol adăugat în coșul de cumpărături online");
        System.out.println("Selectati preferință pentru ambalaj cadou");
        System.out.println("Selecati adresa de livrare.");
    }

    @Override
    public void dePlatit() {
        System.out.println("Plata online prin Net banking, Card sau Paypal");
    }

    @Override
    public void deLivrat(){
        System.out.println("Expediați articolul prin oficiul poștal la adresa de livrare");
    }
}

class ComandaMagazin extends ProcesareComandaTemplate {

    @Override
    public void deSelectat() {
        System.out.println("Clientul alege articolul de pe raft.");
    }

    @Override
    public void dePlatit() {
        System.out.println("Plătește la casa prin numerar/POS");
    }

    @Override
    public void deLivrat()  {
        System.out.println("Articol livrat la ghișeul de livrari");
    }
}
